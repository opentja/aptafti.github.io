TEM copper grid bar
This dataset contains five 2D images from a TEM copper grid bar sample and 
its 3D surface model (.off format).
The set of 2D images were obtained by tilting the specimen stage 11 
degrees from one to the next in the image sequence.

http://selibcv.org/3dsem/